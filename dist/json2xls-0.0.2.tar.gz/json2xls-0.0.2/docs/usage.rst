========
Usage
========

To use json2xls in a project::

    import json2xls