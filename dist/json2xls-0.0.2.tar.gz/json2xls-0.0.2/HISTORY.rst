.. :changelog:

History
-------

0.0.2 (2014-09-24)
---------------------

* add callback for no dict depth limit
* update title style
* col width auto adjust
* fixed headers bug
* support json of line in file


0.0.1 (2014-09-23)
---------------------

* First release on PyPI.
