#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_json2xls
----------------------------------

Tests for `json2xls` module.
"""

import unittest

from json2xls import json2xls


class TestJson2xls(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()