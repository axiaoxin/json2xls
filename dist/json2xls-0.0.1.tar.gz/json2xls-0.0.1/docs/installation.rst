============
Installation
============

At the command line::

    $ easy_install json2xls

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv json2xls
    $ pip install json2xls